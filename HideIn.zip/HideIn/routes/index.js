var express = require('express');
var router = express.Router();
var ctrlMain = require("../main");

/*
 * GET home page.
 */
router.get('/', ctrlMain.home);

/*
 * GET login fields page.
 */
router.get('/login', ctrlMain.get_login);

/*
 * POST login fields page.
 */
router.post('/login', ctrlMain.post_login);


/*
 * GET sign up fields page.
 */
router.get('/signup', ctrlMain.get_signup);

/*
 * POST sign up fields page.
 */
router.post('/signup', ctrlMain.post_signup);

module.exports = router;