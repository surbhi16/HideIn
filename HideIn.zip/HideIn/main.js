var lineReader = require('line-reader');

/**
 * Send the contents of an HTML page to the client.
 * @param fileName the name of the file containing the HTML page.
 * @param result the HTTP result.
 */
function sendPage(fileName, result)
{
    var html = '';
    
    // Read the file one line at a time.
    lineReader.eachLine(fileName,
        /**
         * Append each line to string html.
         * Send the contents of html to the client
         * after the last line has been read.
         * @param line the line read from the file.
         * @param last set to true after the last line.
         */
        function(line, last)
        {
            html += line + '\n\n';

            if (last) 
            { 
                result.send(html);
                return false; 
            }
            else
            {
                return true;
            }
        });
}

/**
 * Send the contents of an HTML page to the client
 * with an inserted body text.
 * @param text the body text.
 * @param result the HTTP result.
 */
function sendBody_login(text, result)
{
    var html = '<!DOCTYPE html>\n'
        + '<html lang="en-US">\n'
        + '<head>\n'
        + '    <meta charset="UTF-8">\n'
        + '    <title>HideIn</title>\n'
        + '</head>\n'
        + '<body>\n'
        + '    <h1>Welcome to HideIn, '+ text +' </h1>\n'
        + '<img src="https://images4.alphacoders.com/862/thumb-1920-862732.jpg" width="1024" height="720">'
        + '\n'
        + '</body>\n'
        + '</html>\n';
    
    result.send(html);    
}


/**
 * Send the contents of an HTML page to the client
 * with an inserted body text.
 * @param text the body text.
 * @param result the HTTP result.
 */
function sendBody_signup(text, result)
{
    var html = '<!DOCTYPE html>\n'
        + '<html lang="en-US">\n'
        + '<head>\n'
        + '    <meta charset="UTF-8">\n'
        + '    <title>HideIn</title>\n'
        + '</head>\n'
        + '<body>\n'
        + '    <h1>HideIn,  home for every student!</h1>'
        + '    <h3>'+ text +'</h3>\n'
        + '\n'
        + '</body>\n'
        + '</html>\n';
    
    result.send(html);    
}

/* 
 * GET home page.
 */
module.exports.home = function(request, result) 
{
    sendPage('homepage.html', result);
};

/*
 * GET login fields page.
 */
module.exports.get_login = function(request, result) 
{
    sendPage('login.html', result);
};

/*
 * POST login success page.
 */
module.exports.post_login = function(request, result) 
{
	var uid = request.param('userId');
    var pwd  = request.param('password');
    var text = uid;
    sendBody_login(text, result);
};

/*
 * GET sign up fields page.
 */
module.exports.get_signup = function(request, result) 
{
    sendPage('signup.html', result);
};

/*
 * POST sign up success page.
 */
module.exports.post_signup = function(request, result) 
{
	var firstName = request.param('firstName');
    var lastName  = request.param('lastName');
    var emailId  = request.param('emailId');
    var phoneNumber  = request.param('phoneNumber');
    
    var success = 'Sign up successful!';
    sendBody_signup(success,result);
    
};

